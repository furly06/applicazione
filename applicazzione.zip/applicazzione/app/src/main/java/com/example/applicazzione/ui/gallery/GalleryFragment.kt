package com.example.applicazzione.ui.gallery

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.applicazzione.R
import com.example.applicazzione.databinding.FragmentGalleryBinding

class GalleryFragment : Fragment() {


    // QUESTA è LA LISTA DI RICETTE DI CUCINA
    // IDEE: BISOGNA FINIRLA CONFIGUANDO GLI OGGETTI DELLA LISTA


    private var _binding: FragmentGalleryBinding? = null
    private val binding get() = _binding!!

    private val fruitList = arrayOf("Caprese", "Cornetti_salati", "Ciambella_allarancia")
    private val fruitImage = arrayOf(R.drawable.caprese, R.drawable.cornetti_salati, R.drawable.ciambella_allarancia)

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentGalleryBinding.inflate(inflater, container, false)
        val root: View = binding.root


        // IL PROGRAMMA CRASHA CI DEVE ESSERE UNALTRO MODO DDI DFARLO
        // val listView: ListView = binding.customListview
        //val customAdapter = Custom(requireContext(), fruitList, fruitImage)
        // Check if customAdapter is not null before setting it
        //listView.adapter = customAdapter

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class Custom(ctx: Context, private val fruit: Array<String>, private val fruitImage: Array<Int>) : BaseAdapter() {

    private val inflater: LayoutInflater = LayoutInflater.from(ctx)

    override fun getCount(): Int {
        return fruit.size
    }

    override fun getItem(position: Int): Any {
        return fruit[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: inflater.inflate(R.layout.activity_item, parent, false)

        val text: TextView = view.findViewById(R.id.textView)
        val imageView: ImageView = view.findViewById(R.id.imageView)

        text.text = fruit[position]
        imageView.setImageResource(fruitImage[position])

        return view
    }
}
