package com.example.applicazzione.ui.home

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.applicazzione.databinding.FragmentHomeBinding
import com.google.android.material.textfield.TextInputEditText
import java.lang.Exception


// IDEE GENERALI: FARE UNA LISTA DI RICETTE, GESTIRE MEGLIO IL CALCOLO DEL METABOLISMO
//      IMPLEMENTARE LE NOTIFICHE.


// IL CODICE è IN KOTLIN mi scuso


class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null

    // QUESTA è LA PAGINA INIZIALE CONTIENE IL METABOLISMO BASALE
    // IDEE: SPOSTARLA IN UNA PAGINA SECONDARIA



    private val binding get() = _binding!!

    @SuppressLint("SetTextI18n")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val homeViewModel =
            ViewModelProvider(this).get(HomeViewModel::class.java)

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textHome
        homeViewModel.text.observe(viewLifecycleOwner) {
            textView.text = "Calcolo Metabolismo Basale"
        }

        val risultato: TextView = binding.Risultato


        val buttone: Button = binding.button2
        buttone.text="INVIO"
        val Altezza: EditText = binding.Altezza
        val Peso: EditText = binding.Peso
        val Sesso: TextInputEditText = binding.Sesso
        val Eta: EditText = binding.Eta


        buttone.setOnClickListener( View.OnClickListener {
            if(Sesso.text.toString().lowercase().trim().equals( "maschio")){

                var peso    :      Double =0.0
                var altezza :   Double=0.0
                var eta     :       Int=0
                try{
                    peso = Peso.text.toString().toDouble()
                    altezza=  Altezza.text.toString().toDouble()
                    eta = Eta.text.toString().toInt()
                    risultato.text = ""+CalcoloUomo(peso, altezza, eta)
                }catch (e: Exception){}
            }else if (Sesso.text.toString().lowercase().trim().equals( "femmina")) {
                var peso: Double = 0.0
                var altezza: Double = 0.0
                var eta: Int = 0
                try {
                    peso = Peso.text.toString().toDouble()
                    altezza = Altezza.text.toString().toDouble()
                    eta = Eta.text.toString().toInt()
                    risultato.text = "" + CalcoloDonna(peso, altezza, eta)
                } catch (e: Exception) {}
            }

        })









        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    fun CalcoloUomo(peso : Double, altezza : Double, eta : Int ): Double {
        return 66.47+(13.75*peso+5*altezza)-(6.75*eta)
    }


    fun CalcoloDonna(peso : Double, altezza : Double, eta : Int ): Double {
        return 655.09 +(9.56*peso+1.84*altezza)-(4.67*eta)
    }
}