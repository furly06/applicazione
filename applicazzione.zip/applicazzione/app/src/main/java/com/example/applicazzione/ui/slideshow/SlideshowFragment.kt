package com.example.applicazzione.ui.slideshow

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.applicazzione.databinding.FragmentSlideshowBinding
import com.google.android.material.textfield.TextInputEditText
import java.lang.Exception

class SlideshowFragment : Fragment() {


    // QUESTA è LA PAGINA DEL MATABOLISMO BASALE * L'INDICE
    // IDEE: UNIRLA ALLTATRA DEL CALCOLO BASALE E DIFFERENZIARLO DALL'ALTRO ATTRAVERSO UNA SCELTA MULTIPLA




    private var _binding: FragmentSlideshowBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val slideshowViewModel =
            ViewModelProvider(this).get(SlideshowViewModel::class.java)

        _binding = FragmentSlideshowBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textSlideshow
        slideshowViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }
        val buttone: Button = binding.button
        buttone.text="INVIO"
        val Altezza: EditText = binding.editTextNumber2
        val Peso: EditText = binding.editTextNumber3
        val Sesso: TextInputEditText = binding.textSesso
        val Eta: EditText = binding.editTextNumber
        val risultato: TextView = binding.Risultato2
        val attivita: TextInputEditText = binding.attivita


        buttone.setOnClickListener( View.OnClickListener {
            if(Sesso.text.toString().lowercase().trim().equals( "maschio")){

                var peso    :      Double =0.0
                var altezza :   Double=0.0
                var eta     :       Int=0
                var att : String
                try{
                    peso = Peso.text.toString().toDouble()
                    altezza=  Altezza.text.toString().toDouble()
                    eta = Eta.text.toString().toInt()
                    att = attivita.text.toString()
                    risultato.text = ""+CalcoloUomo(peso, altezza, eta, att)



                }catch (e: Exception){}
            }else if (Sesso.text.toString().lowercase().trim().equals( "femmina")) {
                var peso: Double = 0.0
                var altezza: Double = 0.0
                var eta: Int = 0
                var att : String

                try {
                    peso = Peso.text.toString().toDouble()
                    altezza = Altezza.text.toString().toDouble()
                    eta = Eta.text.toString().toInt()
                    att = attivita.text.toString()

                    risultato.text = "" + CalcoloDonna(peso, altezza, eta, att)
                } catch (e: Exception) {}
            }
        })
        return root

    }fun CalcoloUomo(peso: Double, altezza: Double, eta: Int, att: String): Double {
            var ris : Double = 0.0
            if (att.equals("sedentario")){
                ris = (66.47+(13.75*peso+5*altezza)-(6.75*eta)) * 1.45
            }
            if (att.equals("poco attivo"))
                ris = (66.47+(13.75*peso+5*altezza)-(6.75*eta)) * 1.60
            if (att.equals("attivo"))
                ris = (66.47+(13.75*peso+5*altezza)-(6.75*eta)) * 1.75
            if (att.equals("poco attivo"))
                ris = (66.47+(13.75*peso+5*altezza)-(6.75*eta)) * 2.1





            return ris
        }


            fun CalcoloDonna(peso : Double, altezza : Double, eta : Int, att: String ): Double {
                var ris : Double = 0.0
                if (att.equals("sedentario")){
                    ris = (66.47+(13.75*peso+5*altezza)-(6.75*eta)) * 1.45
                }
                if (att.equals("poco attivo"))
                    ris = (66.47+(13.75*peso+5*altezza)-(6.75*eta)) * 1.60
                if (att.equals("attivo"))
                    ris = (66.47+(13.75*peso+5*altezza)-(6.75*eta)) * 1.75
                if (att.equals("poco attivo"))
                    ris = (66.47+(13.75*peso+5*altezza)-(6.75*eta)) * 2.1

                return ris
            }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}